package hu.gypt.musicplayer

import android.content.Context
import android.widget.Toast

const val LOG_ID = "MusicPlayer XYZ"

fun showToast(context: Context, s: String, length: Boolean){
    Toast.makeText(context, s, if(length) Toast.LENGTH_SHORT else Toast.LENGTH_LONG).show();
}

