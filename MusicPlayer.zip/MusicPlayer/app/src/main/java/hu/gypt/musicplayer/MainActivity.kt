package hu.gypt.musicplayer

import android.media.MediaPlayer
import android.media.MediaPlayer.OnPreparedListener
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Bundle
import android.util.Log
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import hu.gypt.musicplayer.databinding.ActivityMainBinding
import java.util.*


// lejátszáshoz MediaPlayer.OnPreparedListener implementálása
class MainActivity : AppCompatActivity(), MediaPlayer.OnPreparedListener  {
    private lateinit var binding: ActivityMainBinding
    private var notifyTonePlay = false
    private lateinit var mediaPlayer: MediaPlayer


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        initUI(initRingTonePlay())

        mediaPlayer = MediaPlayer.create(this@MainActivity,
            R.raw.monkeyislandtheme)
                //monkeyislandtheme:2:42 -> 162xxx ms
        
        Log.i(LOG_ID,"currentPosition: ${mediaPlayer.currentPosition}\n" +
                "duration: ${mediaPlayer.duration}\n"
        )



        binding.buttonPlayPause.setOnClickListener {
            Log.i(LOG_ID,"playbutton pressed!")

            /*
            mediaPlayer.setOnPreparedListener(OnPreparedListener {
                Log.i(LOG_ID,"setOnPreparedListener meghívva!")
                it.start() })
             */
            mediaPlayer.setOnPreparedListener(this@MainActivity)
        }

        binding.buttonStop.setOnClickListener {
            Log.i(LOG_ID,"stopbutton pressed!")
            mediaPlayer.stop()
            //mediaPlayer?.seekTo(61000)
        }





        /*
        mediaPlayer = MediaPlayer.create(this@MainActivity,
            Uri.parse("https://vgmsite.com/soundtracks/f29-retaliator-ms-dos/xvjskzgz/01_Title%20Screen.mp3"))

        Log.i(LOG_ID,"currentPosition: ${mediaPlayer.currentPosition}\n" +
                "duration: ${mediaPlayer.duration}\n" +
                "playbackParams: ${mediaPlayer.playbackParams}\n" +
                "trackInfo: ${mediaPlayer.trackInfo}\n"
                )

        binding.seekBar.min = 0
        binding.seekBar.max = mediaPlayer.duration


        binding.buttonPlayPause.setOnClickListener {
            mediaPlayer.setOnPreparedListener(this@MainActivity)
        }

        binding.buttonStop.setOnClickListener {
            mediaPlayer?.stop()
            //mediaPlayer?.seekTo(61000)
        }

        */

    }

    private fun playNotifyTone(notifytone: Ringtone, run: Boolean) {
            if (run) {
                notifytone.play()
                notifyTonePlay = true
            } else {
                notifytone.stop()
                notifyTonePlay = false
            }
    }

    private fun initUI(rt: Ringtone){
        binding.notifybutton.setCompoundDrawablesWithIntrinsicBounds(getDrawable(android.R.drawable.ic_media_play), null, null, null)

        binding.notifybutton.setOnClickListener {
            if (!notifyTonePlay){
                playNotifyTone(rt, true)
                binding.notifybutton.setCompoundDrawablesWithIntrinsicBounds(getDrawable(android.R.drawable.ic_media_pause), null, null, null)
            }
            else {
                playNotifyTone(rt, false)
                binding.notifybutton.setCompoundDrawablesWithIntrinsicBounds(getDrawable(android.R.drawable.ic_media_play), null, null, null)
            }
        }

        //https://www.geeksforgeeks.org/dynamic-seekbar-in-kotlin/
        binding.seekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                    binding.seekbarreporter.text = seekBar.progress.toString() + "%"
                }

                override fun onStartTrackingTouch(seekBar: SeekBar) {
                    // write custom code when touch is started.
                    // lejátszás leáll
                }

                override fun onStopTrackingTouch(seekBar: SeekBar) {
                    // write custom code when touch is stopped
                    // lejátszás tovább
                    /*
                    Toast.makeText(this@MainActivity,
                        "SeekBar Progress is: " + seekBar.progress + "%",
                        Toast.LENGTH_SHORT).show()

                     */
                }
            })
    }

    private fun initRingTonePlay(): Ringtone{
        val notifiesSounds = arrayOf(
            RingtoneManager.TYPE_RINGTONE,
            RingtoneManager.TYPE_ALARM,
            RingtoneManager.TYPE_NOTIFICATION
        )

        val randomizer = Random()
        val rand = randomizer.nextInt(notifiesSounds.size)
        Log.i(LOG_ID, "$rand")

        val uriNotif = RingtoneManager.getDefaultUri(
            notifiesSounds[rand]
        )

        Log.i(LOG_ID, "uriNotif: $uriNotif")
        val notiftone = RingtoneManager.getRingtone(
            applicationContext, uriNotif
        )
        return notiftone
    }

    override fun onPrepared(p0: MediaPlayer) {
        Log.i(LOG_ID, "onPrepared meghívva!")
        //p0.start()
        mediaPlayer.start()
    }

    override fun onStop() {
        mediaPlayer.stop()
        super.onStop()
    }

}